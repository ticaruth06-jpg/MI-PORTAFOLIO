# Actividad N° 03 — Programación Orientada a Objetos
Universidad Peruana Los Andes — Desarrollo de Aplicaciones I

Aplicación web Java (Maven, Jakarta EE / Tomcat 11) que implementa las dos
actividades del anexo con un diseño en capas: **modelo** (clases con la
lógica de negocio) → **servlet** (controlador) → **JSP** (vista).

## Estructura del proyecto

```
ActividadPOO03/
├── pom.xml
└── src/main/
    ├── java/com/upla/actividad03/
    │   ├── model/
    │   │   ├── CompraProducto.java     (Actividad 01)
    │   │   └── CompraPasaje.java       (Actividad 02)
    │   └── servlet/
    │       ├── TiendaServlet.java
    │       └── TransporteServlet.java
    └── webapp/
        ├── index.jsp
        ├── tienda.jsp / resultadoTienda.jsp
        ├── transporte.jsp / resultadoTransporte.jsp
        ├── css/style.css
        └── WEB-INF/web.xml
```

## Actividad 01 — Tienda
Clase `CompraProducto`: dado el precio de la docena y la cantidad de
docenas, calcula importe de compra, descuento (20% si docenas ≥ 10,
10% si < 10), importe a pagar y lapiceros de obsequio (2 por docena
si el importe a pagar ≥ 200).

## Actividad 02 — Transportes Lima-Huancayo
Clase `CompraPasaje`: dado el turno y la cantidad de pasajes (precio
fijo S/. 37.5), calcula importe de compra, descuento (8% si pasajes
≥ 15, 5% si < 15), importe a pagar y caramelos de obsequio (2 por
boleto si el importe a pagar > 200).

## Cómo abrir y ejecutar en NetBeans (Tomcat 11)

1. **Requisitos previos**
   - JDK 17 o superior instalado.
   - Apache Tomcat 11 registrado en NetBeans (`Services → Servers →
     Add Server… → Apache Tomcat`), o instalarlo en
     `Tools → Servers`.
   - Maven ya viene integrado en NetBeans (no requiere instalación aparte).

2. **Abrir el proyecto**
   - `File → Open Project…` y seleccionar la carpeta `ActividadPOO03`
     (la que contiene el `pom.xml`). NetBeans la reconoce
     automáticamente como proyecto Maven de tipo *war*.

3. **Configurar el servidor del proyecto**
   - Clic derecho sobre el proyecto → `Properties → Run`.
   - En **Server**, seleccionar `Apache Tomcat 11`.
   - Aceptar los cambios.

4. **Ejecutar**
   - Clic derecho sobre el proyecto → `Run` (o `Shift + F6`).
   - NetBeans compila con Maven, empaqueta el `.war` y lo despliega
     en Tomcat. Se abrirá el navegador en
     `http://localhost:8080/ActividadPOO03/`.

5. **Compilar el `.war` por línea de comandos (opcional)**
   ```
   mvn clean package
   ```
   El archivo resultante queda en `target/ActividadPOO03.war` y puede
   copiarse directamente a la carpeta `webapps` de Tomcat 11.

## Notas de diseño
- Los JSP no contienen lógica de negocio: solo reciben el objeto ya
  calculado (`compra` o `pasaje`) mediante `request.setAttribute()`
  y lo muestran con Expression Language (`${...}`) y JSTL
  (`fmt:formatNumber`).
- Los servlets usan las anotaciones `@WebServlet` (API
  `jakarta.servlet`, requerida por Tomcat 11 / Jakarta EE 10), por lo
  que no es obligatorio declarar servlets en `web.xml`.
- Se validan los datos de entrada (numéricos y no negativos); ante un
  error se vuelve al formulario mostrando un mensaje.
