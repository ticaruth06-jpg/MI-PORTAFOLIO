<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="jakarta.tags.fmt" prefix="fmt" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Resultado - Actividad 02</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <h1>Actividad 02 · Resultado</h1>
        <p>Compra de pasajes</p>
    </header>

    <div class="container">
        <h2>Detalle de la compra</h2>

        <table class="resultado">
            <tr>
                <td>Turno</td>
                <td>${pasaje.turno}</td>
            </tr>
            <tr>
                <td>Precio del pasaje</td>
                <td>S/. 37.50</td>
            </tr>
            <tr>
                <td>Cantidad de pasajes</td>
                <td>${pasaje.cantidadPasajes}</td>
            </tr>
            <tr>
                <td>Importe de la compra</td>
                <td>S/. <fmt:formatNumber value="${pasaje.importeCompra}" minFractionDigits="2" maxFractionDigits="2"/></td>
            </tr>
            <tr>
                <td>Importe del descuento</td>
                <td>S/. <fmt:formatNumber value="${pasaje.importeDescuento}" minFractionDigits="2" maxFractionDigits="2"/></td>
            </tr>
            <tr>
                <td>Importe a pagar</td>
                <td>S/. <fmt:formatNumber value="${pasaje.importeAPagar}" minFractionDigits="2" maxFractionDigits="2"/></td>
            </tr>
            <tr>
                <td>Caramelos de obsequio</td>
                <td>${pasaje.cantidadCaramelos}</td>
            </tr>
        </table>

        <a class="volver" href="transporte.jsp">&larr; Nueva compra</a> ·
        <a class="volver" href="index.jsp">Portafolio</a>
    </div>
</body>
</html>
