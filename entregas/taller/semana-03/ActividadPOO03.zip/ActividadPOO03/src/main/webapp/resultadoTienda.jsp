<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="jakarta.tags.fmt" prefix="fmt" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Resultado - Actividad 01</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <h1>Actividad 01 · Resultado</h1>
        <p>Compra en tienda</p>
    </header>

    <div class="container">
        <h2>Detalle de la compra</h2>

        <table class="resultado">
            <tr>
                <td>Precio de la docena</td>
                <td>S/. <fmt:formatNumber value="${compra.precioDocena}" minFractionDigits="2" maxFractionDigits="2"/></td>
            </tr>
            <tr>
                <td>Docenas adquiridas</td>
                <td>${compra.cantidadDocenas}</td>
            </tr>
            <tr>
                <td>Importe de la compra</td>
                <td>S/. <fmt:formatNumber value="${compra.importeCompra}" minFractionDigits="2" maxFractionDigits="2"/></td>
            </tr>
            <tr>
                <td>Importe del descuento</td>
                <td>S/. <fmt:formatNumber value="${compra.importeDescuento}" minFractionDigits="2" maxFractionDigits="2"/></td>
            </tr>
            <tr>
                <td>Importe a pagar</td>
                <td>S/. <fmt:formatNumber value="${compra.importeAPagar}" minFractionDigits="2" maxFractionDigits="2"/></td>
            </tr>
            <tr>
                <td>Lapiceros de obsequio</td>
                <td>${compra.cantidadLapiceros}</td>
            </tr>
        </table>

        <a class="volver" href="tienda.jsp">&larr; Nueva compra</a> ·
        <a class="volver" href="index.jsp">Portafolio</a>
    </div>
</body>
</html>
