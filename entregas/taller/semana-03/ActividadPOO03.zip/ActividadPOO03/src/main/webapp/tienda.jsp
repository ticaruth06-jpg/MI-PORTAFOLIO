<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Actividad 01 - Tienda</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <h1>Actividad 01</h1>
        <p>Descuento por docenas y lapiceros de obsequio</p>
    </header>

    <div class="container">
        <h2>Datos de la compra</h2>

        <% if (request.getAttribute("mensajeError") != null) { %>
            <div class="error"><%= request.getAttribute("mensajeError") %></div>
        <% } %>

        <form action="TiendaServlet" method="post">
            <label for="precioDocena">Precio de la docena (S/.)</label>
            <input type="number" step="0.01" min="0" id="precioDocena" name="precioDocena" required>

            <label for="cantidadDocenas">Cantidad de docenas adquiridas</label>
            <input type="number" min="0" id="cantidadDocenas" name="cantidadDocenas" required>

            <button type="submit">Calcular</button>
        </form>

        <a class="volver" href="index.jsp">&larr; Volver al portafolio</a>
    </div>
</body>
</html>
