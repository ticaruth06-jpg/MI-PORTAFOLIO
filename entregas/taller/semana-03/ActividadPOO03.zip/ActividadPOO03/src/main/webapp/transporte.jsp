<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Actividad 02 - Transportes</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <h1>Actividad 02</h1>
        <p>Ruta Lima - Huancayo · Descuento y caramelos de obsequio</p>
    </header>

    <div class="container">
        <h2>Datos de la compra</h2>

        <% if (request.getAttribute("mensajeError") != null) { %>
            <div class="error"><%= request.getAttribute("mensajeError") %></div>
        <% } %>

        <form action="TransporteServlet" method="post">
            <label for="turno">Turno</label>
            <select id="turno" name="turno" required>
                <option value="Mañana">Mañana</option>
                <option value="Noche">Noche</option>
            </select>

            <label for="cantidadPasajes">Cantidad de pasajes adquiridos</label>
            <input type="number" min="0" id="cantidadPasajes" name="cantidadPasajes" required>

            <button type="submit">Calcular</button>
        </form>

        <a class="volver" href="index.jsp">&larr; Volver al portafolio</a>
    </div>
</body>
</html>
