<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Actividad N° 03 - Programación Orientada a Objetos</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <h1>Universidad Peruana Los Andes - Facultad de Ingeniería</h1>
        <p>Desarrollo de Aplicaciones I · Actividad N° 03 · Programación Orientada a Objetos</p>
    </header>

    <div class="container">
        <h2>Portafolio de ejercicios</h2>
        <p>Seleccione el ejercicio que desea ejecutar:</p>

        <a class="card-link" href="tienda.jsp">
            <strong>Actividad 01 · Tienda</strong>
            Cálculo de importe, descuento y lapiceros de obsequio por compra de docenas.
        </a>

        <a class="card-link" href="transporte.jsp">
            <strong>Actividad 02 · Transportes Lima - Huancayo</strong>
            Cálculo de importe, descuento y caramelos de obsequio por compra de pasajes.
        </a>
    </div>
</body>
</html>
