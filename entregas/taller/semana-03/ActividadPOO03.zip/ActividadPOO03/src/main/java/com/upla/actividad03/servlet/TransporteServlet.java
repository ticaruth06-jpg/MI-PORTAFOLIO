package com.upla.actividad03.servlet;

import com.upla.actividad03.model.CompraPasaje;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/**
 * Controlador (Servlet) de la Actividad 02: recibe los datos del
 * formulario, delega el calculo al modelo CompraPasaje y reenvia
 * el resultado a la vista JSP.
 */
@WebServlet(name = "TransporteServlet", urlPatterns = {"/TransporteServlet"})
public class TransporteServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        try {
            String turno = request.getParameter("turno");
            int cantidadPasajes = Integer.parseInt(request.getParameter("cantidadPasajes").trim());

            if (turno == null || turno.isBlank() || cantidadPasajes < 0) {
                throw new NumberFormatException("Datos invalidos");
            }

            CompraPasaje pasaje = new CompraPasaje(turno, cantidadPasajes);
            request.setAttribute("pasaje", pasaje);
            request.getRequestDispatcher("resultadoTransporte.jsp").forward(request, response);

        } catch (NumberFormatException | NullPointerException ex) {
            request.setAttribute("mensajeError",
                    "Seleccione el turno e ingrese una cantidad de pasajes valida y positiva.");
            request.getRequestDispatcher("transporte.jsp").forward(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("transporte.jsp");
    }
}
