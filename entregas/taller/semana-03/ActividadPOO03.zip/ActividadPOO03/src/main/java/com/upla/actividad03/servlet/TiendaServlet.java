package com.upla.actividad03.servlet;

import com.upla.actividad03.model.CompraProducto;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/**
 * Controlador (Servlet) de la Actividad 01: recibe los datos del
 * formulario, delega el calculo al modelo CompraProducto y reenvia
 * el resultado a la vista JSP.
 */
@WebServlet(name = "TiendaServlet", urlPatterns = {"/TiendaServlet"})
public class TiendaServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        try {
            double precioDocena = Double.parseDouble(request.getParameter("precioDocena").trim());
            int cantidadDocenas = Integer.parseInt(request.getParameter("cantidadDocenas").trim());

            if (precioDocena < 0 || cantidadDocenas < 0) {
                throw new NumberFormatException("Los valores no pueden ser negativos");
            }

            CompraProducto compra = new CompraProducto(precioDocena, cantidadDocenas);
            request.setAttribute("compra", compra);
            request.getRequestDispatcher("resultadoTienda.jsp").forward(request, response);

        } catch (NumberFormatException | NullPointerException ex) {
            request.setAttribute("mensajeError",
                    "Ingrese valores numericos validos y positivos en todos los campos.");
            request.getRequestDispatcher("tienda.jsp").forward(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("tienda.jsp");
    }
}
