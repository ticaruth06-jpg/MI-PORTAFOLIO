package com.upla.actividad03.model;

/**
 * Actividad 01
 * Modela la compra de un producto por docenas, con descuento segun
 * la cantidad de docenas adquiridas y lapiceros de obsequio segun
 * el importe a pagar.
 *
 * Reglas de negocio:
 *  - Descuento: 20% si docenas >= 10 ; 10% si docenas < 10
 *  - Obsequio: 2 lapiceros por cada docena si el importe a pagar >= 200 ; 0 en caso contrario
 *
 * @author Nayeli Quispe Tica
 */
public class CompraProducto {

    private static final double PORCENTAJE_DESCUENTO_ALTO = 0.20;
    private static final double PORCENTAJE_DESCUENTO_BAJO = 0.10;
    private static final int LIMITE_DOCENAS = 10;
    private static final double LIMITE_IMPORTE_OBSEQUIO = 200.0;
    private static final int LAPICEROS_POR_DOCENA = 2;

    private double precioDocena;
    private int cantidadDocenas;

    private double importeCompra;
    private double importeDescuento;
    private double importeAPagar;
    private int cantidadLapiceros;

    public CompraProducto(double precioDocena, int cantidadDocenas) {
        this.precioDocena = precioDocena;
        this.cantidadDocenas = cantidadDocenas;
        procesarCompra();
    }

    /**
     * Orquesta el calculo completo de la compra.
     */
    private void procesarCompra() {
        calcularImporteCompra();
        calcularImporteDescuento();
        calcularImporteAPagar();
        calcularLapiceros();
    }

    private void calcularImporteCompra() {
        this.importeCompra = precioDocena * cantidadDocenas;
    }

    private void calcularImporteDescuento() {
        double porcentaje = (cantidadDocenas >= LIMITE_DOCENAS)
                ? PORCENTAJE_DESCUENTO_ALTO
                : PORCENTAJE_DESCUENTO_BAJO;
        this.importeDescuento = importeCompra * porcentaje;
    }

    private void calcularImporteAPagar() {
        this.importeAPagar = importeCompra - importeDescuento;
    }

    private void calcularLapiceros() {
        this.cantidadLapiceros = (importeAPagar >= LIMITE_IMPORTE_OBSEQUIO)
                ? cantidadDocenas * LAPICEROS_POR_DOCENA
                : 0;
    }

    // ---------- Getters (usados por las vistas JSP con EL: ${compra.xxx}) ----------

    public double getPrecioDocena() {
        return precioDocena;
    }

    public int getCantidadDocenas() {
        return cantidadDocenas;
    }

    public double getImporteCompra() {
        return importeCompra;
    }

    public double getImporteDescuento() {
        return importeDescuento;
    }

    public double getImporteAPagar() {
        return importeAPagar;
    }

    public int getCantidadLapiceros() {
        return cantidadLapiceros;
    }
}
