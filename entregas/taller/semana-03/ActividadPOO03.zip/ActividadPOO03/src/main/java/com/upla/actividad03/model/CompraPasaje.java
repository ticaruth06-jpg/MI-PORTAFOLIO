package com.upla.actividad03.model;

/**
 * Actividad 02
 * Modela la compra de pasajes de la ruta Lima - Huancayo (turno manana
 * o noche, ambos al mismo precio), con descuento segun la cantidad de
 * pasajes adquiridos y caramelos de obsequio segun el importe a pagar.
 *
 * Reglas de negocio:
 *  - Precio de pasaje: S/. 37.5 (fijo, para ambos turnos)
 *  - Descuento: 8% si pasajes >= 15 ; 5% si pasajes < 15
 *  - Obsequio: 2 caramelos por cada boleto si el importe a pagar > 200 ; 0 en caso contrario
 *
 * @author Nayeli Quispe Tica
 */
public class CompraPasaje {

    public static final double PRECIO_PASAJE = 37.5;

    private static final double PORCENTAJE_DESCUENTO_ALTO = 0.08;
    private static final double PORCENTAJE_DESCUENTO_BAJO = 0.05;
    private static final int LIMITE_PASAJES = 15;
    private static final double LIMITE_IMPORTE_OBSEQUIO = 200.0;
    private static final int CARAMELOS_POR_BOLETO = 2;

    private String turno;
    private int cantidadPasajes;

    private double importeCompra;
    private double importeDescuento;
    private double importeAPagar;
    private int cantidadCaramelos;

    public CompraPasaje(String turno, int cantidadPasajes) {
        this.turno = turno;
        this.cantidadPasajes = cantidadPasajes;
        procesarCompra();
    }

    /**
     * Orquesta el calculo completo de la compra.
     */
    private void procesarCompra() {
        calcularImporteCompra();
        calcularImporteDescuento();
        calcularImporteAPagar();
        calcularCaramelos();
    }

    private void calcularImporteCompra() {
        this.importeCompra = PRECIO_PASAJE * cantidadPasajes;
    }

    private void calcularImporteDescuento() {
        double porcentaje = (cantidadPasajes >= LIMITE_PASAJES)
                ? PORCENTAJE_DESCUENTO_ALTO
                : PORCENTAJE_DESCUENTO_BAJO;
        this.importeDescuento = importeCompra * porcentaje;
    }

    private void calcularImporteAPagar() {
        this.importeAPagar = importeCompra - importeDescuento;
    }

    private void calcularCaramelos() {
        this.cantidadCaramelos = (importeAPagar > LIMITE_IMPORTE_OBSEQUIO)
                ? cantidadPasajes * CARAMELOS_POR_BOLETO
                : 0;
    }

    // ---------- Getters (usados por las vistas JSP con EL: ${pasaje.xxx}) ----------

    public String getTurno() {
        return turno;
    }

    public int getCantidadPasajes() {
        return cantidadPasajes;
    }

    public double getImporteCompra() {
        return importeCompra;
    }

    public double getImporteDescuento() {
        return importeDescuento;
    }

    public double getImporteAPagar() {
        return importeAPagar;
    }

    public int getCantidadCaramelos() {
        return cantidadCaramelos;
    }
}
